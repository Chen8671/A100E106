<?Php
var_dump($_POST);
?>

