<!DOCTYPE html>
<html>
<body>

<h1 align="center">早餐代訂費用試算</h1>

<form action="/ordercontroller.php" method="post"> 
  <label  for="">訂購者使用者:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <label for="">數量:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <input type="radio" name="location" value="1"> 豆漿<br>
  <input type="radio" name="location" value="2"> 奶茶<br>
  <input type="radio" name="location" value="3"> 珍珠+五元<br>
  <input type="submit" value="GO">
  
</form>
<form>

</form>

<p></p>

</body>
</html>
